import { appendCapsuleEntry, createCapsule } from '../api/capsuleApi.js';
import { imageApi } from '../api/imageApi.js';

export class CapsuleFormHandler {
    /**
     * @param {Object} mapPicker 3D 지도 좌표 피커 객체 (선택)
     */
    constructor(mapPicker = null) {
        this.mapPicker = mapPicker;
        this.initEvents();
    }

    /**
     * DOM 이벤트 리스너 바인딩
     */
    initEvents() {
        // sidebar.html의 #memory-upload 폼 제출 감지 (이벤트 위임)
        document.addEventListener('submit', async (e) => {
            if (e.target && e.target.id === 'memory-upload') {
                await this.handleSubmit(e);
            }
        });
        window.addEventListener('capsuleLocationPicked', (event) => this.createMemoryCapsule(event.detail));
    }

    /**
     * ISO-8601 OffsetDateTime 포맷 변환 (YYYY-MM-DDTHH:mm:ss+09:00)
     */
    formatToOffsetDateTime(dateObj = new Date()) {
        const tzo = -dateObj.getTimezoneOffset();
        const dif = tzo >= 0 ? '+' : '-';
        const pad = (num) => (num < 10 ? '0' : '') + num;

        return dateObj.getFullYear() +
            '-' + pad(dateObj.getMonth() + 1) +
            '-' + pad(dateObj.getDate()) +
            'T' + pad(dateObj.getHours()) +
            ':' + pad(dateObj.getMinutes()) +
            ':' + pad(dateObj.getSeconds()) +
            dif + pad(Math.floor(Math.abs(tzo) / 60)) +
            ':' + pad(Math.abs(tzo) % 60);
    }

    /**
     * 폼 제출 처리 및 API 호출
     */
    async handleSubmit(e) {
        e.preventDefault(); // 기본 URL 이동(GET) 방지

        const userId = localStorage.getItem('userId');
        const capsuleId = document.getElementById('memory-group')?.value;
        const memo = document.getElementById('memory-memo')?.value || '';
        let lat = parseFloat(document.getElementById('memory-lat')?.value || 0);
        let lng = parseFloat(document.getElementById('memory-lon')?.value || 0);
        const fileInput = document.getElementById('memory-file');
        const selectedFile = fileInput?.files[0];

        const nowIso = this.formatToOffsetDateTime(new Date());
        let imagesPayload = [];

        try {
            if (!userId) throw new Error('사용자 정보를 찾지 못했습니다. 다시 로그인해 주세요.');
            if (!capsuleId) throw new Error('사진을 저장할 추억 묶음을 먼저 선택해 주세요.');
            // 2. 이미지가 첨부된 경우 FormData를 생성하여 이미지 업로드 API 먼저 호출
            if (selectedFile) {
                const uploadResult = await imageApi.uploadImage(selectedFile);
                if ((!lat || !lng) && uploadResult.latitude != null && uploadResult.longitude != null) {
                    lat = Number(uploadResult.latitude);
                    lng = Number(uploadResult.longitude);
                    document.getElementById('memory-lat').value = lat;
                    document.getElementById('memory-lon').value = lng;
                }

                // 서버에서 저장 후 반환한 실제 웹 접근 경로 설정
                imagesPayload.push({
                    originalFilePath: uploadResult.originalFilePath,   // 예: /images/original/2026/09/16/uuid_file.jpg
                    compressedFilePath: uploadResult.compressedFilePath, // 예: /images/compressed/2026/09/16/uuid.webp
                    takenAt: nowIso
                });
            }

            const payload = {
                userId,
                memo: memo,
                images: imagesPayload
            };

            await appendCapsuleEntry(capsuleId, payload);
            alert('🎉 선택한 추억 묶음에 사진과 기록을 저장했습니다!');
            
            // 폼 초기화
            e.target.reset();

            // 생성 완료 후 지도 재조회 이벤트 발신
            window.dispatchEvent(new CustomEvent('capsuleCreated', { detail: { capsuleId: Number(capsuleId) } }));
        } catch (err) {
            console.error(err);
            alert('캡슐 등록에 실패했습니다: ' + err.message);
        }
    }

    async createMemoryCapsule(location) {
        const title = window.pendingCapsuleTitle;
        if (!title) return;
        const userId = localStorage.getItem('userId');
        try {
            if (!userId) throw new Error('사용자 정보를 찾지 못했습니다. 다시 로그인해 주세요.');
            const result = await createCapsule({
                userId, title, memo: '', longitude: location.longitude, latitude: location.latitude,
                altitude: location.altitude || 0, startedAt: this.formatToOffsetDateTime(), images: []
            });
            window.pendingCapsuleTitle = null;
            window.dispatchEvent(new CustomEvent('capsuleCreated', { detail: { capsuleId: result.data } }));
            alert('새 추억 묶음이 생성되었습니다. 이제 사진과 기록을 저장할 수 있어요.');
        } catch (error) {
            window.pendingCapsuleTitle = null;
            alert(`새 추억 묶음 생성에 실패했습니다: ${error.message}`);
        }
    }

    /**
     * 3D 지형 클릭 피킹 시 좌표를 폼 Input에 자동으로 채워주는 함수
     */
    setLocationInputs(loc) {
        const latInput = document.getElementById('memory-lat');
        const lonInput = document.getElementById('memory-lon');

        if (latInput && lonInput) {
            latInput.value = loc.latitude;
            lonInput.value = loc.longitude;
        }
    }
}
