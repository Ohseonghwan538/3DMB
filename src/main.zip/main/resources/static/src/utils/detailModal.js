export class DetailModal {
    static open(capsule) {
        let modal = document.getElementById('capsule-detail-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'capsule-detail-modal';
            modal.className = 'modal-overlay';
            document.body.appendChild(modal);
        }

        const escapeHtml = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        })[char]);
        const images = capsule.images || [];
        const imageSlides = images.map((img, idx) => `
            <div class="slide ${idx === 0 ? 'active' : ''}">
                <img src="${encodeURI(img.originalFilePath)}" alt="추억 사진" onerror="this.onerror=null;this.src='/src/components/NO.png'">
            </div>
        `).join('');

        modal.innerHTML = `
            <div class="modal-content">
                <button class="modal-close" type="button" aria-label="상세 창 닫기">×</button>
                <h2>${escapeHtml(capsule.title)}</h2>
                <p class="capsule-date">📅 ${new Date(capsule.startedAt).toLocaleDateString()}</p>
                <div class="carousel-container">${imageSlides || '<p>등록된 사진이 없습니다.</p>'}</div>
                <div class="capsule-memo"><p>${escapeHtml(capsule.memo)}</p></div>
            </div>
        `;
        modal.querySelector('.modal-close')?.addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (event) => { if (event.target === modal) modal.remove(); }, { once: true });
    }
}
