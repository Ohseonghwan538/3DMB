export function renderCapsuleBillboard(Module, capsule) {
    if (!Module || capsule.latitude == null || capsule.longitude == null) return;

    const key = `capsule_${capsule.capsuleId}`;
    const symbol = Module.getSymbol();
    const layers = new Module.JSLayerList(true);
    let layer = layers.nameAtLayer?.('CAPSULES') || layers.createLayer('CAPSULES', Module.ELT_BILLBOARD);

    // 기존 빌보드 중복 제거
    if (layer?.searchObject?.(key)) {
        layer.removeAtKey?.(key);
    }

    const thumbUrl = capsule.images?.[0]?.compressedFilePath || '/src/components/NO.png';

    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
        try {
            const canvas = document.createElement('canvas');
            canvas.width = 120; canvas.height = 120;height
            const ctx = canvas.getContext('2d');
            
            ctx.beginPath(); ctx.arc(60, 60, 54, 0, Math.PI * 2); ctx.clip();
            ctx.drawImage(img, 0, 0, 120, 120);

            // [수정 포인트] 아이콘 이름에 타임스탬프를 붙여 엔진 캐시 중복 방지
            const uniqueIconKey = `icon_${key}_${Date.now()}`;
            symbol.insertIcon(uniqueIconKey, ctx.getImageData(0, 0, 120, 120).data, 120, 120);

            const billboard = Module.createBillboard(key);
            billboard.set(
                new Module.JSVector3D(Number(capsule.longitude), Number(capsule.latitude), Number(capsule.altitude || 0) + 15),
                symbol.getIcon(uniqueIconKey),
                50, 50
            );
            
            billboard.capsuleData = capsule;
            layer.addObject(billboard, key);
        } catch (e) {
            console.error('캔버스 이미지 데이터 추출 실패 (CORS 의심):', e);
            // 실패 시 기본 이미지로 재시도하도록 트리거
            img.onerror();
        }
    };

    img.onerror = () => {
        if (img.src.endsWith('/src/components/NO.png')) return;
        console.warn(`캡슐 이미지가 없어 기본 썸네일로 대체합니다: ${thumbUrl}`);
        img.src = '/src/components/NO.png';
    };

    img.src = thumbUrl;
}