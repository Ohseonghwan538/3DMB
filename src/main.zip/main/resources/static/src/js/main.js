// main.js

import { tileLayer } from "./layers/TileLayer.js";
import { renderCapsuleBillboard } from '../api/markerRenderer.js';
import { BoundsDetector } from '../utils/boundsDetector.js';
import { MapPicker } from '../utils/picker.js';
import { CapsuleFormHandler } from '../utils/capsuleForm.js';
import { DetailModal } from '../utils/detailModal.js';

/**
 * 🔑 세션 확인 및 localStorage 동기화
 */
async function initSession() {
    try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
            const user = await response.json();
            // 서버 세션의 실제 userId를 localStorage에 동기화
            localStorage.setItem('userId', user.userId);
            console.log('✅ 로그인 사용자 세션 확인:', user.userId);
        } else {
            localStorage.removeItem('userId');
            alert('로그인이 만료되었습니다. 다시 로그인해 주세요.');
            window.location.href = '/login';
        }
    } catch (error) {
        console.error('세션 확인 실패:', error);
    }
}

// 애플리케이션 진입 시 세션 검증 실행
initSession();

// 3D 엔진 로드 완료 후 실행
window.addEventListener("XDWorldLoaded", function () {
    console.log("🚀 3D 엔진 초기화 완료");

    // 건물 3D 타일 레이어 초기화
    tileLayer.init();

    document.getElementById("map-loader")?.classList.add("is-done");
    const status = document.getElementById("map-status-text");
    if (status) status.textContent = "3D 지도 연결됨";

    initApplication(window.Module);
});

window.addEventListener("toggleBuildingLayer", (event) => tileLayer.setVisible(event.detail.visible));

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("home-view")?.addEventListener("click", () => location.reload());
    document.getElementById("fullscreen")?.addEventListener("click", () => {
        document.fullscreenElement ? document.exitFullscreen?.() : document.documentElement.requestFullscreen?.();
    });
});

/**
 * 애플리케이션 모듈 통합 초기화
 */
function initApplication(Module) {
    const canvas = document.querySelector('#map canvas') || document.getElementById('map');
    const moduleObj = window.Module || Module;

    if (!canvas) {
        console.error("❌ Map Canvas 엘리먼트를 찾을 수 없습니다.");
        return;
    }

    // 1. 3D 객체 클릭 콜백 바인딩 (엔진 초기화 완료 후 안전하게 설정)
    moduleObj.cbSelectObject = function(layerName, objectKey) {
        if (layerName === 'CAPSULES') {
            const layers = new moduleObj.JSLayerList(true);
            const layer = layers.nameAtLayer('CAPSULES');
            const billboard = layer?.searchObject(objectKey);

            if (billboard && billboard.capsuleData) {
                DetailModal.open(billboard.capsuleData); // 상세 모달 열기
            }
        }
    };

    // 2. 가시 영역 캡슐 수신 콜백
    const handleCapsulesLoaded = (capsules) => {
        console.log(`📌 가시 영역 내 조회된 캡슐 개수: ${capsules.length}`);
        capsules.forEach(capsule => renderCapsuleBillboard(moduleObj, capsule));
    };

    // 3. 지도 영역 감지기 실행
    const boundsDetector = new BoundsDetector(moduleObj, canvas, handleCapsulesLoaded);
    boundsDetector.initEventListeners();

    // 4. Capsule Form Handler 객체 우선 생성
    const capsuleFormHandler = new CapsuleFormHandler();

    // 5. MapPicker 단일 인스턴스화 및 전역 연결
    window.mapPicker = new MapPicker(moduleObj, canvas, (pickedLocation) => {
        capsuleFormHandler.setLocationInputs(pickedLocation);
        window.dispatchEvent(new CustomEvent('capsuleLocationPicked', { detail: pickedLocation }));
    });

    // 6. 새 캡슐 생성 이벤트 수신 시 지도 마커 즉시 재조회
    window.addEventListener('capsuleCreated', () => {
        boundsDetector.triggerBoundsSearch();
    });
}
