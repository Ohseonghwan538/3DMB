import { fetchCapsulesByUser } from '../api/capsuleApi.js';
import { DetailModal } from '../utils/detailModal.js';

let capsules = [];

function formatDate(value) {
    return value ? new Date(value).toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' }) : '날짜 없음';
}

async function loadHistory(selectedCapsuleId = null) {
    const userId = localStorage.getItem('userId');
    const select = document.getElementById('memory-group');
    const feedback = document.getElementById('memory-feedback');
    if (!userId || !select) return;

    try {
        capsules = await fetchCapsulesByUser(userId);
        select.innerHTML = '<option value="">추억 묶음을 선택하세요</option>' + capsules.map((capsule) =>
            `<option value="${capsule.capsuleId}">${formatDate(capsule.startedAt)} · ${escapeHtml(capsule.title || '나의 3D 추억')} (${capsule.images?.length || 0})</option>`
        ).join('');
        if (selectedCapsuleId && capsules.some((capsule) => String(capsule.capsuleId) === String(selectedCapsuleId))) {
            select.value = String(selectedCapsuleId);
        }
        if (feedback) feedback.textContent = capsules.length ? `${capsules.length}개의 추억 묶음을 불러왔습니다.` : '아직 저장된 추억이 없습니다.';
    } catch (error) {
        if (feedback) feedback.textContent = error.message;
    }
}

function escapeHtml(value) {
    const node = document.createElement('span'); node.textContent = value; return node.innerHTML;
}

document.addEventListener('sidebarLoaded', () => {
    document.getElementById('memory-group')?.addEventListener('change', (event) => {
        const selected = capsules.find((capsule) => String(capsule.capsuleId) === event.target.value);
        if (selected) DetailModal.open(selected);
    });
    document.getElementById('refresh-memories')?.addEventListener('click', loadHistory);
    loadHistory();
});

window.addEventListener('capsuleCreated', (event) => loadHistory(event.detail?.capsuleId));
