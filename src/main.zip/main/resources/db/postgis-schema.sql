-- 1. PostGIS 확장 설치 (공간 정보용)
CREATE EXTENSION IF NOT EXISTS postgis;

-- 2. 👤 사용자 테이블 생성 (참조 무결성을 위해 가장 먼저 생성)
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. 📦 캡슐(이벤트 그룹) 테이블
-- 하나의 캡슐(그룹)이 지도상의 하나의 위치(마커)와 메모를 갖도록 역할 재조정
CREATE TABLE IF NOT EXISTS capsules (
    capsule_id BIGSERIAL PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    
    -- 내용 (기존 이미지 테이블의 memo 이동 및 제목 추가)
    title VARCHAR(255),
    memo TEXT,
    
    -- 공간 정보 (PostGIS Point, 기존 이미지 테이블에서 이동)
    location GEOMETRY(Point, 4326),
    longitude NUMERIC(11, 8),
    latitude NUMERIC(10, 8),
    altitude NUMERIC(7, 2),
    
    -- 이벤트 기록 기간 (기존 요구사항 유지)
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ended_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- 외래키 설정 (사용자 탈퇴 시 캡슐도 삭제되도록 CASCADE)
    CONSTRAINT fk_capsules_user FOREIGN KEY (user_id) 
        REFERENCES users (user_id) ON DELETE CASCADE
);

-- 캡슐 단위의 공간 정보 GiST(R-Tree) 인덱스 및 위경도 B-Tree 인덱스
CREATE INDEX IF NOT EXISTS idx_capsules_location ON capsules USING GIST (location);
CREATE INDEX IF NOT EXISTS idx_capsules_lat_lng ON capsules (latitude, longitude);


-- 4. 🖼 캡슐 첨부 이미지 테이블
-- 위치와 메모는 캡슐로 넘기고, 여기서는 순수하게 파일 경로와 촬영 시간만 관리
CREATE TABLE IF NOT EXISTS capsule_images (
    image_id BIGSERIAL PRIMARY KEY,
    capsule_id BIGINT NOT NULL,
    
    original_file_path VARCHAR(500) NOT NULL,
    compressed_file_path VARCHAR(500) NOT NULL,
    
    taken_at TIMESTAMP WITH TIME ZONE NOT NULL,   -- 개별 사진 촬영 시간
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- 외래키 설정 (캡슐 삭제 시 이미지 데이터도 삭제)
    CONSTRAINT fk_images_capsule FOREIGN KEY (capsule_id) 
        REFERENCES capsules (capsule_id) ON DELETE CASCADE
);

-- 캡슐 내에서 촬영 시간순 정렬을 위한 복합 인덱스
CREATE INDEX IF NOT EXISTS idx_capsule_images_taken ON capsule_images (capsule_id, taken_at DESC);
