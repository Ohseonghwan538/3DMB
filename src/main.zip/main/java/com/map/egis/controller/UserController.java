package com.map.egis.controller;

import com.map.egis.dto.UserDTO;
import com.map.egis.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserController {

    private final UserService userService;

    // 의존성 주입
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // 🏠 localhost:8080 접속 시 바로 /login으로 이동
    @GetMapping("/")
    public String index() {
        return "redirect:/login";
    }

    // 📄 로그인 페이지 요청 Handling
    @GetMapping("/login")
    public String loginPage() {
        return "forward:/src/components/login.html";
    }

    // 📄 메인 페이지 요청 Handling
    @GetMapping("/main")
    public String mainPage() {
        return "forward:/src/components/index.html";
    }

    // 회원가입 페이지 이동
    @GetMapping("/register")
    public String registerPage() {
        return "forward:/src/components/register.html";
    }

    // 회원가입 요청 처리
    @PostMapping("/register")
    public String register(UserDTO user) {
        boolean isSuccess = userService.register(user);

        if (isSuccess) {
            // ✅ 성공 시 로그인 페이지로 리다이렉트
            return "redirect:/login?registered=true";
        } else {
            // ❌ 실패(아이디 중복 등) 시 에러 파라미터와 함께 회원가입 페이지로 리다이렉트
            return "redirect:/register?error=true";
        }
    }

    // 📥 로그인 처리 (POST)
    @PostMapping("/login")
    public String login(@RequestParam("userId") String userId,
                        @RequestParam("password") String password,
                        HttpSession session) {

        UserDTO loginUser = userService.login(userId, password);

        if (loginUser != null) {
            // 🔑 로그인 성공: 세션에 사용자 정보(아이디 및 이름) 저장
            session.setAttribute("loginUserId", loginUser.getUserId());
            session.setAttribute("loginUserName", loginUser.getName());
            return "redirect:/main"; // 메인 페이지로 이동
        } else {
            // ❌ 로그인 실패: 다시 로그인 페이지로 이동
            return "redirect:/login?error=true";
        }
    }

    // 로그인된 세션 정보 조회 API
    @GetMapping("/api/auth/me")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getCurrentUser(HttpSession session) {
        String userId = (String) session.getAttribute("loginUserId");
        String userName = (String) session.getAttribute("loginUserName");

        // 세션에 저장된 유저 정보가 없는 경우 401 Unauthorized 반환
        if (userId == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("userId", userId);
        userInfo.put("userName", userName);

        return ResponseEntity.ok(userInfo);
    }

    // 🚪 로그아웃 처리
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // 세션 무효화 (모든 세션 정보 삭제)
        session.invalidate();
        return "redirect:/login";
    }
}
