package com.map.egis.controller;

import com.map.egis.config.StorageProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.nio.file.Path;

/** Serves saved media and gives legacy, missing records a harmless visual fallback. */
@RestController
@RequiredArgsConstructor
public class MediaFileController {
    private final StorageProperties storageProperties;

    @GetMapping({"/images/original/**", "/images/compressed/**"})
    public ResponseEntity<Resource> image(HttpServletRequest request) throws MalformedURLException {
        String uri = request.getRequestURI();
        boolean compressed = uri.startsWith("/images/compressed/");
        String prefix = compressed ? "/images/compressed/" : "/images/original/";
        String relativePath = uri.substring(prefix.length()).replace('\\', '/');
        Path root = compressed ? storageProperties.compressedDirectory() : storageProperties.originalDirectory();
        Path resolved = root.resolve(relativePath).normalize();

        if (!relativePath.contains("..") && resolved.startsWith(root)) {
            Resource resource = new UrlResource(resolved.toUri());
            if (resource.exists() && resource.isReadable()) {
                return ResponseEntity.ok().contentType(contentType(relativePath)).body(resource);
            }
        }

        return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG)
                .body(new ClassPathResource("static/src/components/NO.png"));
    }

    private MediaType contentType(String filename) {
        String lower = filename.toLowerCase();
        if (lower.endsWith(".webp")) return MediaType.parseMediaType("image/webp");
        if (lower.endsWith(".png")) return MediaType.IMAGE_PNG;
        return MediaType.IMAGE_JPEG;
    }
}
