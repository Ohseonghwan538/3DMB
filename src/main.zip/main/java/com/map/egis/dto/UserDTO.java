package com.map.egis.dto;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
public class UserDTO {
    private String userId;
    private String password;
    private String name;
    private OffsetDateTime createdAt;
}