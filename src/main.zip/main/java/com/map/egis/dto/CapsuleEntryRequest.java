package com.map.egis.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CapsuleEntryRequest {
    private String userId;
    private String memo;
    private List<CapsuleCreateRequest.ImageDto> images;
}
