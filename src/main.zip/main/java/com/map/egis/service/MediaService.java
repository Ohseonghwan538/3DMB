package com.map.egis.service;

import com.map.egis.config.StorageProperties;
import lombok.RequiredArgsConstructor;
import net.coobird.thumbnailator.Thumbnails;
import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.exif.GpsDirectory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MediaService {
    private static final long MAX_SIZE = 20L * 1024 * 1024;
    private static final Set<String> TYPES = Set.of("image/jpeg", "image/png", "image/webp");
    private final StorageProperties storageProperties;

    static { ImageIO.scanForPlugins(); }

    public UploadedImage store(MultipartFile file) {
        if (file == null || file.isEmpty() || file.getSize() > MAX_SIZE || !TYPES.contains(file.getContentType())) {
            throw new IllegalArgumentException("JPEG, PNG, WebP 형식의 20MB 이하 사진만 등록할 수 있습니다.");
        }

        String extension = extension(file.getOriginalFilename());
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        String name = UUID.randomUUID() + "." + extension;
        Path original = storageProperties.originalDirectory().resolve(date).resolve(name);
        String previewName = UUID.randomUUID() + ".webp";
        Path compressed = storageProperties.compressedDirectory().resolve(date).resolve(previewName);

        try {
            Files.createDirectories(original.getParent());
            Files.createDirectories(compressed.getParent());
            file.transferTo(original);
            if (ImageIO.read(original.toFile()) == null) throw new IllegalArgumentException("열 수 없는 이미지 파일입니다.");
            Thumbnails.of(original.toFile()).size(1600, 1600).outputFormat("webp").outputQuality(0.82).toFile(compressed.toFile());
            Gps gps = gps(original);
            return new UploadedImage("/images/original/" + date + "/" + name, "/images/compressed/" + date + "/" + previewName, gps.latitude(), gps.longitude(), gps.altitude());
        } catch (IOException | RuntimeException error) {
            delete(original); delete(compressed);
            if (error instanceof IllegalArgumentException invalid) throw invalid;
            throw new IllegalStateException("사진을 저장하는 중 문제가 발생했습니다.", error);
        }
    }

    private String extension(String filename) {
        String value = filename == null ? "jpg" : filename.substring(filename.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        return value.equals("jpeg") ? "jpg" : value;
    }
    private void delete(Path path) { try { Files.deleteIfExists(path); } catch (IOException ignored) { } }
    private Gps gps(Path file) {
        try {
            GpsDirectory directory = ImageMetadataReader.readMetadata(file.toFile()).getFirstDirectoryOfType(GpsDirectory.class);
            if (directory != null && directory.getGeoLocation() != null && !directory.getGeoLocation().isZero()) {
                return new Gps(directory.getGeoLocation().getLatitude(), directory.getGeoLocation().getLongitude(), 0D);
            }
        } catch (Exception ignored) { }
        return new Gps(null, null, null);
    }
    private record Gps(Double latitude, Double longitude, Double altitude) { }
    public record UploadedImage(String originalFilePath, String compressedFilePath, Double latitude, Double longitude, Double altitude) { }
}
