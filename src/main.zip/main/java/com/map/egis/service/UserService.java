package com.map.egis.service;

import com.map.egis.mapper.UserMapper;
import com.map.egis.dto.UserDTO;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    // 생성자 주입 (DI)
    public UserService(UserMapper userMapper, PasswordEncoder passwordEncoder) {
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
    }

    // ➕ 회원가입 (비밀번호 암호화 후 DB 저장)
    public boolean register(UserDTO user) {
        if (user == null || isBlank(user.getUserId()) || isBlank(user.getPassword()) || isBlank(user.getName())
                || user.getUserId().length() < 3 || user.getUserId().length() > 40 || user.getPassword().length() < 8) {
            return false;
        }
        user.setUserId(user.getUserId().trim());
        user.setName(user.getName().trim());
        // 1. 아이디 중복 확인
        if (userMapper.countByUserId(user.getUserId()) > 0) {
            // 중복된 아이디가 존재할 경우 false 반환 (또는 커스텀 예외 발생 가능)
            return false; 
        }
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        userMapper.insertUser(user);
        return true;
    }

    // 🔑 로그인 검증 로직
    public UserDTO login(String userId, String rawPassword) {
        if (isBlank(userId) || isBlank(rawPassword)) {
            return null;
        }
        // 1. DB에서 사용자 조회
        UserDTO user = userMapper.findByUserId(userId);

        // 2. 사용자가 존재하지 않는 경우
        if (user == null) {
            return null;
        }

        // 3. 비밀번호 일치 여부 확인 (평문 비밀번호 vs 암호화된 비밀번호)
        if (passwordEncoder.matches(rawPassword, user.getPassword())) {
            return user; // 로그인 성공 시 사용자 객체 반환
        } else {
            return null; // 비밀번호 불일치
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
