package com.map.egis.service;

import com.map.egis.dto.CapsuleResponse;
import com.map.egis.dto.CapsuleSearchRequest;
import com.map.egis.dto.CapsuleCreateRequest;
import com.map.egis.dto.CapsuleEntryRequest;
import com.map.egis.mapper.CapsuleMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CapsuleService {

    private final CapsuleMapper capsuleMapper;

    public CapsuleService(CapsuleMapper capsuleMapper) {
        this.capsuleMapper = capsuleMapper;
    }

    @Transactional
    public long createCapsule(CapsuleCreateRequest request) {
        validate(request);
        // 1. capsules 테이블 저장 (부모)
        capsuleMapper.insertCapsule(request);
        
        // keyProperty로 세팅된 capsule_id 획득
        long generatedCapsuleId = request.getCapsuleId(); 

        // 2. capsule_images 테이블 저장 (자식 - 첨부 이미지가 있는 경우)
        if (request.getImages() != null && !request.getImages().isEmpty()) {
            capsuleMapper.insertCapsuleImages(generatedCapsuleId, request.getImages());
        }

        return generatedCapsuleId;
    }

    @Transactional
    public void appendEntry(long capsuleId, CapsuleEntryRequest request) {
        if (request == null || request.getUserId() == null || request.getUserId().isBlank()) throw new IllegalArgumentException("사용자 ID가 필요합니다.");
        String userId = request.getUserId().trim();
        if (capsuleMapper.countCapsuleByIdAndUserId(capsuleId, userId) == 0) throw new IllegalArgumentException("선택한 추억 묶음을 찾을 수 없습니다.");
        if (request.getImages() == null || request.getImages().isEmpty()) throw new IllegalArgumentException("저장할 사진이 필요합니다.");
        if (request.getImages().size() > 10) throw new IllegalArgumentException("한 번에 사진은 최대 10장까지 추가할 수 있습니다.");
        if (request.getMemo() != null && request.getMemo().length() > 5000) throw new IllegalArgumentException("기록은 5,000자까지 입력할 수 있습니다.");
        capsuleMapper.insertCapsuleImages(capsuleId, request.getImages());
        capsuleMapper.appendMemo(capsuleId, userId, request.getMemo() == null ? "" : request.getMemo().trim());
    }

    private void validate(CapsuleCreateRequest request) {
        if (request == null || request.getUserId() == null || request.getUserId().isBlank()) throw new IllegalArgumentException("로그인 사용자 정보가 필요합니다.");
        if (request.getLatitude() == null || request.getLongitude() == null || request.getLatitude() < -90 || request.getLatitude() > 90 || request.getLongitude() < -180 || request.getLongitude() > 180) throw new IllegalArgumentException("지도에서 올바른 위치를 선택해 주세요.");
        if (request.getTitle() == null || request.getTitle().isBlank()) request.setTitle("나의 3D 추억");
        request.setTitle(request.getTitle().trim().substring(0, Math.min(request.getTitle().trim().length(), 255)));
        if (request.getMemo() != null && request.getMemo().length() > 5000) throw new IllegalArgumentException("메모는 5,000자까지 입력할 수 있습니다.");
        if (request.getStartedAt() == null) request.setStartedAt(java.time.OffsetDateTime.now());
        if (request.getImages() != null && request.getImages().size() > 10) throw new IllegalArgumentException("한 캡슐에는 사진을 최대 10장까지 등록할 수 있습니다.");
    }

    @Transactional(readOnly = true)
    public List<CapsuleResponse> getCapsulesInBounds(CapsuleSearchRequest request) {
        if (request.getUserId() == null || request.getUserId().isBlank()) throw new IllegalArgumentException("사용자 ID가 필요합니다.");
        return capsuleMapper.selectCapsulesInBounds(
            request.getUserId().trim(),
            request.getMinLongitude(),
            request.getMinLatitude(),
            request.getMaxLongitude(),
            request.getMaxLatitude()
        );
    }

    @Transactional(readOnly = true)
    public List<CapsuleResponse> getCapsulesByUserId(String userId) {
        if (userId == null || userId.isBlank()) throw new IllegalArgumentException("사용자 ID가 필요합니다.");
        return capsuleMapper.selectCapsulesByUserId(userId.trim());
    }
}
