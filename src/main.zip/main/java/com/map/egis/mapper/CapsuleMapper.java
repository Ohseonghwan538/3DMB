package com.map.egis.mapper;

import com.map.egis.dto.CapsuleCreateRequest;
import com.map.egis.dto.CapsuleResponse;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CapsuleMapper {
    // capsules 저장 (자동 생성된 PK가 request 객체 내부 필드에 세팅됨)
    void insertCapsule(CapsuleCreateRequest request);

    // capsule_images 일괄 저장 (Batch Insert)
    void insertCapsuleImages(
        @Param("capsuleId") long capsuleId, 
        @Param("images") List<CapsuleCreateRequest.ImageDto> images
    );
    
    // 화면 영영(Bounding Box) 범위 내 캡슐 및 이미지 조인 조회
    List<CapsuleResponse> selectCapsulesInBounds(
        @Param("userId") String userId,
        @Param("minLng") Double minLng,
        @Param("minLat") Double minLat,
        @Param("maxLng") Double maxLng,
        @Param("maxLat") Double maxLat
    );
    List<CapsuleResponse> selectCapsulesByUserId(@Param("userId") String userId);
    int countCapsuleByIdAndUserId(@Param("capsuleId") long capsuleId, @Param("userId") String userId);
    int appendMemo(@Param("capsuleId") long capsuleId, @Param("userId") String userId, @Param("memo") String memo);
}
