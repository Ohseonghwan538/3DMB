package com.map.egis.mapper;

import com.map.egis.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserMapper {
    // 🔍 아이디로 회원 정보 조회 (로그인 시 사용)
    UserDTO findByUserId(@Param("userId") String userId);

    // ➕ 회원가입 (테스트 데이터 삽입용)
    int insertUser(UserDTO user);

    // 🔍 아이디 중복 확인 (존재하면 1, 없으면 0 반환)
    int countByUserId(@Param("userId") String userId);
}
